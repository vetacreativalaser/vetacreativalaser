
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';
import { KeyRound } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient'; // Direct Supabase client for this specific flow

const ResetPasswordPage = () => {
  const navigate = useNavigate();
  const { updatePassword: authUpdatePassword } = useAuth(); // from context for consistency if user is logged in.
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [tokenValid, setTokenValid] = useState(null); // null: checking, true: valid, false: invalid

  // This effect handles the Supabase specific onPasswordRecovery event
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'PASSWORD_RECOVERY') {
        // If Supabase automatically signs in the user after recovery,
        // this will capture the session. We might not need to do anything
        // specific here if `authUpdatePassword` is used.
        setTokenValid(true); // Assume token was valid if this event fires
      }
    });
    
    // Check if there's an access_token in the URL hash (Supabase recovery flow)
    // This part is tricky because the token might be in the hash fragment
    const hash = window.location.hash;
    if (hash.includes('access_token') && hash.includes('type=recovery')) {
        setTokenValid(true); // Token is likely present
    } else if (tokenValid === null && !hash) { // if no hash and not yet checked
        // setTokenValid(false); // No token, likely invalid direct access (might remove this to avoid premature false)
    }


    return () => {
      subscription?.unsubscribe();
    };
  }, [navigate, tokenValid]);


  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (newPassword !== confirmPassword) {
      toast({ title: "Error", description: "Las contraseñas no coinciden.", variant: "destructive" });
      return;
    }
    if (newPassword.length < 6) {
        toast({ title: "Error", description: "La contraseña debe tener al menos 6 caracteres.", variant: "destructive" });
        return;
    }
    setIsLoading(true);
    try {
      // Supabase's updateUser is used to set the new password when the user is in a recovery session
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;

      toast({ 
        title: "Contraseña restablecida", 
        description: "Tu contraseña ha sido actualizada exitosamente." 
      });
      navigate('/auth?mode=login'); 
    } catch (error) {
      toast({ title: "Error al restablecer", description: error.message || "No se pudo restablecer la contraseña.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };


  return (
    <div className="min-h-screen flex items-center justify-center py-8 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-md w-full space-y-8 p-8 sm:p-10 bg-white shadow-xl border border-gray-200"
      >
        <div>
          <KeyRound className="mx-auto h-12 w-auto text-black" strokeWidth={1.5}/>
          <h2 className="mt-6 text-center text-3xl font-semibold tracking-tight text-black">
            Restablecer Contraseña
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Crea una nueva contraseña para tu cuenta.
          </p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div>
              <Label htmlFor="new-password">Nueva contraseña</Label>
              <Input
                id="new-password"
                name="newPassword"
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="mt-1 border-gray-300 focus:border-black focus:ring-black"
                placeholder="Nueva contraseña"
                disabled={isLoading}
              />
            </div>
            <div>
              <Label htmlFor="confirm-password">Confirmar nueva contraseña</Label>
              <Input
                id="confirm-password"
                name="confirmPassword"
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="mt-1 border-gray-300 focus:border-black focus:ring-black"
                placeholder="Confirmar contraseña"
                disabled={isLoading}
              />
            </div>
          </div>

          <div>
            <Button type="submit" className="w-full bg-black text-white hover:bg-gray-800" disabled={isLoading}>
              {isLoading ? 'Restableciendo...' : 'Restablecer Contraseña'}
            </Button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default ResetPasswordPage;