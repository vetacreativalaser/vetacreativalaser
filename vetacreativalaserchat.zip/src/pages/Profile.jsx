import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Trash2, User, ShoppingBag, LayoutDashboard, Edit3, Save, Lock, Mail } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Link, useNavigate } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const Profile = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [points, setPoints] = useState(0);
  const [level, setLevel] = useState(1);
  const [reviews, setReviews] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [products, setProducts] = useState([]);
  const [purchases, setPurchases] = useState([]);
  const [formData, setFormData] = useState({ name: '', email: '', phone: '' });
  const [isEditing, setIsEditing] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(true);

  const refreshReviews = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('reviews')
      .select('*')
      .eq('name', user.email);
    setReviews(data || []);
  };

  useEffect(() => {
    const fetchProfile = async () => {
      if (!user) return;

      const { data: profile } = await supabase
        .from('profiles')
        .select('points, level, name, phone')
        .eq('email', user.email)
        .single();

      if (profile) {
        setPoints(profile.points || 0);
        setLevel(profile.level || 1);
        setFormData({
          name: profile.name || user.user_metadata?.name || '',
          email: user.email || '',
          phone: profile.phone || user.user_metadata?.phone || ''
        });
      }

      const { data: favs } = await supabase
        .from('favorites')
        .select('*')
        .eq('user_id', user.id);
      setFavorites(favs || []);

      const { data: productList } = await supabase
        .from('products')
        .select('id, name');
      setProducts(productList || []);

      const { data: purchaseData } = await supabase
        .from('purchases')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      setPurchases(purchaseData || []);

      await refreshReviews();
      setLoading(false);
    };
    fetchProfile();
  }, [user]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleEditToggle = () => {
    if (isEditing) {
      handleSaveProfile();
    } else {
      setIsEditing(true);
    }
  };

  const handleSaveProfile = async () => {
    if (!currentPassword) {
      alert('Introduce tu contraseña para confirmar.');
      return;
    }

    const { error: authError } = await supabase.auth.signInWithPassword({
      email: user.email,
      password: currentPassword
    });

    if (authError) {
      alert('Contraseña incorrecta.');
      return;
    }

    await supabase.auth.updateUser({
      data: { name: formData.name, phone: formData.phone }
    });

    await supabase
      .from('profiles')
      .update({ name: formData.name, phone: formData.phone })
      .eq('email', user.email);

    setIsEditing(false);
    setCurrentPassword('');
  };

  const handlePasswordChange = async () => {
    if (!currentPassword || !newPassword || newPassword !== confirmPassword) {
      alert('Verifica las contraseñas.');
      return;
    }

    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) {
      alert('Error al cambiar la contraseña.');
    } else {
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const progress = (points % 80);
  const nextLevel = level + 1;
  const isAdmin = user.email === 'vetacreativalaser@gmail.com';

  if (loading || !user) return <p className="text-center p-10">Cargando perfil...</p>;

  return (
    <div className="max-w-6xl mx-auto py-10 px-4">
      <div className="flex items-center gap-4 mb-6">
        <div className="w-20 h-20 rounded-full bg-gray-200 flex items-center justify-center">
          <User className="w-10 h-10 text-gray-500" />
        </div>
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-black">{user.email}</h1>
          <p className="text-sm text-gray-600">Nivel {level} · {points} puntos</p>
        </div>
        {isAdmin && (
          <Link to="/admin/dashboard">
            <Button variant="secondary" className="text-xs"><LayoutDashboard className="w-4 h-4 mr-1" /> Administrador</Button>
          </Link>
        )}
        <Button variant="destructive" onClick={handleLogout}>Cerrar sesión</Button>
      </div>

      <Tabs defaultValue="principal">
        <TabsList className="grid grid-cols-4 w-full mb-6">
          <TabsTrigger value="principal">Principal</TabsTrigger>
          <TabsTrigger value="info">Info</TabsTrigger>
          <TabsTrigger value="compras">Mis Compras</TabsTrigger>
          <TabsTrigger value="reseñas">Reseñas</TabsTrigger>
        </TabsList>

        <TabsContent value="principal">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="rounded-2xl p-4 bg-white shadow-md border">
              <h2 className="font-semibold text-lg mb-2">Progreso</h2>
              <p className="text-sm">Puntos: {points}</p>
              <p className="text-sm">Nivel actual: {level}</p>
              <div className="mt-2 w-full bg-gray-200 h-3 rounded-full overflow-hidden">
                <div className="bg-green-500 h-full" style={{ width: `${(progress / 80) * 100}%` }}></div>
              </div>
              <p className="text-xs text-gray-600 mt-1">Te faltan {80 - progress} puntos para subir al nivel {nextLevel}</p>
            </div>

            <div className="rounded-2xl p-4 bg-white shadow-md border">
              <div className="flex items-center justify-between mb-2">
                <h2 className="font-semibold text-lg">Favoritos</h2>
                <Link to="/favoritos"><Button size="sm" variant="link">Ver todos</Button></Link>
              </div>
              <ul className="text-sm text-gray-700 space-y-1">
                {favorites.slice(0, 4).map((fav) => {
                  const product = products.find(p => p.id === fav.product_id);
                  return (
                    <li key={fav.id}>• {product?.name || 'Producto eliminado'}</li>
                  );
                })}
                {favorites.length === 0 && <li>No hay favoritos</li>}
              </ul>
            </div>

            <div className="rounded-2xl p-4 bg-white shadow-md border">
              <h2 className="font-semibold text-lg mb-2">Recompensas</h2>
              <p className="text-sm text-gray-600 mb-1">Cada 80 puntos subes un nivel.</p>
              <p className="text-sm text-gray-600">Recibirás regalos sorpresa por correo al subir de nivel 🎁</p>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="info">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="p-4 bg-white border shadow-md rounded-2xl space-y-4">
              <h2 className="text-lg font-semibold">Datos de contacto</h2>
              <Label htmlFor="name">Nombre completo</Label>
              <Input id="name" name="name" value={formData.name} onChange={handleInputChange} disabled={!isEditing} />
              <Label htmlFor="email">Correo electrónico</Label>
              <Input id="email" name="email" value={formData.email} disabled className="bg-gray-100" />
              <Label htmlFor="phone">Teléfono</Label>
              <Input id="phone" name="phone" value={formData.phone} onChange={handleInputChange} disabled={!isEditing} />
              {isEditing && (
                <>
                  <Label htmlFor="currentPassword">Contraseña actual</Label>
                  <Input id="currentPassword" name="currentPassword" type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} />
                </>
              )}
              <Button onClick={handleEditToggle} variant={isEditing ? 'default' : 'outline'}>
                {isEditing ? <><Save className="w-4 h-4 mr-1" />Guardar</> : <><Edit3 className="w-4 h-4 mr-1" />Editar</>}
              </Button>
              {!isEditing && (
                <Link to="/forgot-password">
                  <Button variant="link" className="text-sm text-gray-600 hover:text-black p-0 h-auto">¿Olvidaste tu contraseña?</Button>
                </Link>
              )}
            </div>

            <div className="p-4 bg-white border shadow-md rounded-2xl space-y-4">
              <h2 className="text-lg font-semibold">Cambiar contraseña</h2>
              <Label htmlFor="newPassword">Nueva contraseña</Label>
              <Input id="newPassword" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
              <Label htmlFor="confirmPassword">Confirmar nueva contraseña</Label>
              <Input id="confirmPassword" type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
              <Label htmlFor="currentPassword">Contraseña actual</Label>
              <Input id="currentPassword" type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} />
              <Button onClick={handlePasswordChange} variant="default">Actualizar contraseña</Button>
            </div>

            <div className="p-4 bg-white border shadow-md rounded-2xl space-y-4">
              <h2 className="text-lg font-semibold">Contacto</h2>
              <p className="text-sm text-gray-600">¿Tienes alguna duda o problema? Escríbenos a:</p>
              <div className="flex items-center gap-2 text-sm text-gray-800">
                <Mail className="w-4 h-4" /> soporte@vetacreativa.com
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="compras">
          {purchases.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {purchases.map(purchase => (
                <div key={purchase.id} className="p-4 bg-white border shadow-md rounded-2xl">
                  <h3 className="font-medium text-black flex items-center"><ShoppingBag className="mr-2 h-4 w-4" /> {purchase.name || 'Compra'}</h3>
                  <p className="text-gray-600 text-sm mt-1">{purchase.description}</p>
                  <div className="flex justify-between items-center mt-2">
                    <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                      purchase.status === 'En preparación' ? 'bg-yellow-100 text-yellow-800' :
                      purchase.status === 'Enviado' ? 'bg-blue-100 text-blue-800' :
                      purchase.status === 'Finalizada' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {purchase.status || 'Sin estado'}
                    </span>
                    <p className="text-xs text-gray-500">{new Date(purchase.created_at).toLocaleDateString()}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-500">Aún no has realizado ninguna compra.</p>
          )}
        </TabsContent>

        <TabsContent value="reseñas">
          {reviews.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {reviews.map((r) => (
                <div key={r.id} className="p-4 bg-white border shadow-md rounded-2xl flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-sm text-gray-600 mb-1">{r.name}</p>
                    <div className="text-yellow-500 mb-1">{'★'.repeat(r.rating)}</div>
                    <p className="text-gray-700 text-sm mb-1">{r.comment}</p>
                    <p className="text-xs text-gray-400">{new Date(r.created_at).toLocaleDateString()}</p>
                  </div>
                  <Button onClick={() => alert('Eliminar reseña no implementado')} variant="ghost" size="icon">
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500">No has dejado reseñas todavía.</p>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Profile;
