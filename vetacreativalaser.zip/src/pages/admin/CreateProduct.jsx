
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { PackagePlus, ImagePlus, Trash2, List, PlusCircle, ArrowLeft } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

const CreateProduct = () => {
  const navigate = useNavigate();
  const [productName, setProductName] = useState('');
  const [category, setCategory] = useState('');
  const [price, setPrice] = useState('');
  const [imageUrls, setImageUrls] = useState(['']);
  const [imageAlts, setImageAlts] = useState(['']);
  const [imageTexts, setImageTexts] = useState(['']);
  const [fullDescription, setFullDescription] = useState('');
  const [specifications, setSpecifications] = useState(['']);
  const [isLoading, setIsLoading] = useState(false);

  const handleAddImageUrl = () => {
    setImageUrls([...imageUrls, '']);
    setImageAlts([...imageAlts, '']);
    setImageTexts([...imageTexts, '']);
  };

  const handleRemoveImageUrl = (index) => {
    setImageUrls(imageUrls.filter((_, i) => i !== index));
    setImageAlts(imageAlts.filter((_, i) => i !== index));
    setImageTexts(imageTexts.filter((_, i) => i !== index));
  };

  const handleImageUrlChange = (index, value) => {
    const newUrls = [...imageUrls];
    newUrls[index] = value;
    setImageUrls(newUrls);
  };
  const handleImageAltChange = (index, value) => {
    const newAlts = [...imageAlts];
    newAlts[index] = value;
    setImageAlts(newAlts);
  };
  const handleImageTextChange = (index, value) => {
    const newTexts = [...imageTexts];
    newTexts[index] = value;
    setImageTexts(newTexts);
  };

  const handleAddSpecification = () => {
    setSpecifications([...specifications, '']);
  };

  const handleRemoveSpecification = (index) => {
    setSpecifications(specifications.filter((_, i) => i !== index));
  };

  const handleSpecificationChange = (index, value) => {
    const newSpecs = [...specifications];
    newSpecs[index] = value;
    setSpecifications(newSpecs);
  };
  
  const handleDescriptionChange = (e) => {
    setFullDescription(e.target.value);
  };

  const addBulletPoint = () => {
    setFullDescription(prev => prev + "\n• ");
  };


  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    const productData = {
      name: productName,
      category,
      price,
      image_urls: imageUrls.filter(url => url.trim() !== ''),
      image_alts: imageAlts.filter((_,i) => imageUrls[i].trim() !== ''),
      image_texts: imageTexts.filter((_,i) => imageUrls[i].trim() !== ''),
      full_description: fullDescription,
      specifications: specifications.filter(spec => spec.trim() !== ''),
    };
    
    const { data, error } = await supabase.from('products').insert([productData]).select();
    
    if (error) {
      toast({ title: "Error al crear producto", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Producto Creado", description: `${productName} ha sido añadido.` });
      navigate('/admin/dashboard?tab=products');
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8 bg-gray-100">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-3xl mx-auto bg-white p-8 shadow border border-gray-200"
      >
        <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-semibold text-black">Crear Nuevo Producto</h1>
            <Link to="/admin/dashboard">
                <Button variant="outline" className="border-gray-300 text-black hover:bg-gray-100">
                    <ArrowLeft className="mr-2 h-4 w-4" /> Volver al Dashboard
                </Button>
            </Link>
        </div>
        

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="productName">Nombre del Producto</Label>
            <Input id="productName" value={productName} onChange={(e) => setProductName(e.target.value)} required className="mt-1 border-gray-300 focus:border-black focus:ring-black" placeholder="Ej: Kit San Valentín" disabled={isLoading}/>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="category">Categoría</Label>
              <Input id="category" value={category} onChange={(e) => setCategory(e.target.value)} required className="mt-1 border-gray-300 focus:border-black focus:ring-black" placeholder="Ej: temporada, natalicio" disabled={isLoading}/>
            </div>
            <div>
              <Label htmlFor="price">Precio</Label>
              <Input id="price" type="text" value={price} onChange={(e) => setPrice(e.target.value)} required className="mt-1 border-gray-300 focus:border-black focus:ring-black" placeholder="Ej: 25,99 €" disabled={isLoading}/>
            </div>
          </div>
          
          <div className="space-y-3">
            <Label>Imágenes del Producto (URLs)</Label>
            {imageUrls.map((url, index) => (
              <div key={index} className="space-y-2 p-3 border border-gray-200 bg-gray-50">
                <div className="flex items-center space-x-2">
                    <Input type="url" placeholder="https://ejemplo.com/imagen.jpg" value={url} onChange={(e) => handleImageUrlChange(index, e.target.value)} className="flex-grow border-gray-300 focus:border-black focus:ring-black" disabled={isLoading}/>
                    {imageUrls.length > 1 && (
                      <Button type="button" variant="ghost" size="icon" onClick={() => handleRemoveImageUrl(index)} className="text-red-500 hover:bg-red-100" disabled={isLoading}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                </div>
                <Input type="text" placeholder="Texto alternativo (alt) para la imagen" value={imageAlts[index]} onChange={(e) => handleImageAltChange(index, e.target.value)} className="border-gray-300 focus:border-black focus:ring-black" disabled={isLoading}/>
                <Input type="text" placeholder="Texto descriptivo corto para la imagen (opcional)" value={imageTexts[index]} onChange={(e) => handleImageTextChange(index, e.target.value)} className="border-gray-300 focus:border-black focus:ring-black" disabled={isLoading}/>
              </div>
            ))}
            <Button type="button" variant="outline" onClick={handleAddImageUrl} className="text-sm border-gray-300 text-black hover:bg-gray-100" disabled={isLoading}>
              <ImagePlus className="mr-2 h-4 w-4" /> Añadir URL de Imagen
            </Button>
          </div>

          <div>
            <Label htmlFor="fullDescription">Descripción Completa</Label>
            <Textarea id="fullDescription" value={fullDescription} onChange={handleDescriptionChange} rows={6} className="mt-1 border-gray-300 focus:border-black focus:ring-black" placeholder="Describe tu producto en detalle..." disabled={isLoading}/>
            <Button type="button" variant="outline" size="sm" onClick={addBulletPoint} className="mt-2 text-xs border-gray-300 text-black hover:bg-gray-100" disabled={isLoading}>
              <List className="mr-1 h-3 w-3" /> Añadir Viñeta
            </Button>
          </div>

          <div className="space-y-2">
            <Label>Especificaciones</Label>
            {specifications.map((spec, index) => (
              <div key={index} className="flex items-center space-x-2">
                <Input value={spec} onChange={(e) => handleSpecificationChange(index, e.target.value)} className="flex-grow border-gray-300 focus:border-black focus:ring-black" placeholder="Ej: Material: Madera de abedul" disabled={isLoading}/>
                {specifications.length > 1 && (
                  <Button type="button" variant="ghost" size="icon" onClick={() => handleRemoveSpecification(index)} className="text-red-500 hover:bg-red-100" disabled={isLoading}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
            <Button type="button" variant="outline" onClick={handleAddSpecification} className="text-sm border-gray-300 text-black hover:bg-gray-100" disabled={isLoading}>
              <PlusCircle className="mr-2 h-4 w-4" /> Añadir Especificación
            </Button>
          </div>

          <Button type="submit" size="lg" className="w-full bg-black text-white hover:bg-gray-800 py-3" disabled={isLoading}>
            {isLoading ? <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div> : <PackagePlus className="mr-2 h-5 w-5" />}
            {isLoading ? 'Creando Producto...' : 'Crear Producto'}
          </Button>
        </form>
         <div className="mt-8 p-4 border border-dashed border-gray-300 bg-gray-50">
            <h3 className="text-md font-semibold text-black mb-2">¿Cómo subir imágenes y obtener enlaces?</h3>
            <p className="text-sm text-gray-600 mb-1">Para obtener enlaces de imágenes que funcionen en tu web:</p>
            <ol className="list-decimal list-inside text-sm text-gray-600 space-y-1">
                <li>Usa un servicio de alojamiento de imágenes como <a href="https://imgur.com/upload" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Imgur</a>, <a href="https://postimages.org/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Postimages</a>, o el almacenamiento de <a href="https://supabase.com/docs/guides/storage" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Supabase Storage</a>.</li>
                <li>Sube tu imagen al servicio elegido.</li>
                <li>Una vez subida, busca la opción "Direct Link" (Enlace Directo) o una URL que termine en .jpg, .png, .webp, etc.</li>
                <li>Copia ese enlace directo y pégalo en los campos de "URL de Imagen" de arriba.</li>
                <li>Asegúrate de que el enlace sea público y accesible.</li>
            </ol>
        </div>
      </motion.div>
    </div>
  );
};

export default CreateProduct;
