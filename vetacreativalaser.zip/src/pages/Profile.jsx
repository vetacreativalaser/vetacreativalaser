import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';
import { Edit3, Save, Star, Trash2, Lock, User as UserIcon, LogOut, LayoutDashboard, Heart as HeartIcon, ShoppingBag } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from '@/lib/supabaseClient';

const Profile = () => {
  const { user, updateUser, logout, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', phone: '' });
  const [currentPassword, setCurrentPassword] = useState('');
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false);
  const [userReviews, setUserReviews] = useState([]);
  const [userPurchases, setUserPurchases] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [localLoading, setLocalLoading] = useState(true);

  useEffect(() => {
    const fetchInitialData = async () => {
      setLocalLoading(true);
      if (user) {
        setFormData({
          name: user.name || user.user_metadata?.name || '',
          email: user.email || '',
          phone: user.phone || user.user_metadata?.phone || '',
        });

        const { data: products, error: productsError } = await supabase
          .from('products')
          .select('id, name');
        
        if (productsError) {
          console.error("Error fetching product names:", productsError);
        }

        const { data: reviewsData, error: reviewsError } = await supabase
          .from('reviews')
          .select('*')
          .eq('user_id', user.id);
        
        if (reviewsError) {
          console.error("Error fetching reviews:", reviewsError);
        } else {
          const populatedReviews = (reviewsData || []).map(review => {
            const product = (products || []).find(p => p.id === review.product_id);
            return product ? { ...review, productName: product.name } : { ...review, productName: 'Producto Desconocido' };
          }).filter(Boolean);
          setUserReviews(populatedReviews);
        }

        const { data: purchasesData, error: purchasesError } = await supabase
          .from('purchases')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false });

        if (purchasesError) {
          console.error("Error fetching purchases:", purchasesError);
        } else {
          setUserPurchases(purchasesData || []);
        }

      }
      setLocalLoading(false);
    };
    
    if (!authLoading) {
        fetchInitialData();
    }

  }, [user, authLoading]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleEditToggle = () => {
    if (isEditing) {
      const initialData = {
        name: user.name || user.user_metadata?.name || '',
        email: user.email || '',
        phone: user.phone || user.user_metadata?.phone || '',
      };
      if (JSON.stringify(formData) !== JSON.stringify(initialData)) {
        setShowPasswordPrompt(true);
      } else {
        setIsEditing(false); 
      }
    } else {
      setIsEditing(true); 
    }
  };
  
  const handlePasswordConfirm = async () => {
    setIsLoading(true);
    try {
      await supabase.auth.signInWithPassword({ email: user.email, password: currentPassword });
      await updateUser(formData);
      setIsEditing(false);
      setShowPasswordPrompt(false);
      setCurrentPassword('');
      toast({ title: "Perfil actualizado", description: "Tus datos han sido guardados." });
    } catch (error) {
      toast({ title: "Error al actualizar", description: "Contraseña incorrecta o error al guardar.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleDeleteReview = async (reviewId) => {
    setIsLoading(true);
    const { error } = await supabase
      .from('reviews')
      .delete()
      .eq('id', reviewId)
      .eq('user_id', user.id);

    if (error) {
      toast({ title: "Error al eliminar reseña", description: error.message, variant: "destructive" });
    } else {
      setUserReviews(prev => prev.filter(r => r.id !== reviewId));
      toast({ title: "Reseña eliminada" });
    }
    setIsLoading(false);
  };

  const handleLogout = async () => {
    await logout();
    toast({ title: "Sesión Cerrada", description: "Has cerrado sesión exitosamente." });
    navigate('/');
  };


  if (authLoading || localLoading) {
    return <div className="flex justify-center items-center h-screen"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }
  if (!user) {
    return <div className="text-center py-10">Por favor, inicia sesión para ver tu perfil.</div>;
  }

  const isAdmin = user.email === 'vetacreativalaser@gmail.com';

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-2xl mx-auto bg-white shadow-xl border border-gray-200"
      >
        {isAdmin && (
          <div className="p-4 bg-black text-white text-center">
            <Link to="/admin/dashboard">
              <Button variant="ghost" className="w-full hover:bg-gray-800 text-white">
                <LayoutDashboard className="mr-2 h-5 w-5" /> Panel de Administrador
              </Button>
            </Link>
          </div>
        )}
        <div className="p-8 border-b border-gray-200 flex flex-col items-center">
          <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center mb-4">
            <UserIcon className="w-12 h-12 text-gray-500" strokeWidth={1}/>
          </div>
          <h1 className="text-2xl font-semibold text-black text-center">
            {user.name || user.user_metadata?.name || 'Usuario'}
          </h1>
          <p className="text-sm text-gray-500">{user.email}</p>
        </div>

        <Tabs defaultValue="info" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-gray-100">
            <TabsTrigger value="info" className="data-[state=active]:bg-white data-[state=active]:text-black data-[state=active]:shadow-sm data-[state=inactive]:text-gray-500">Información</TabsTrigger>
            <TabsTrigger value="purchases" className="data-[state=active]:bg-white data-[state=active]:text-black data-[state=active]:shadow-sm data-[state=inactive]:text-gray-500">Mis Compras</TabsTrigger>
            <TabsTrigger value="reviews" className="data-[state=active]:bg-white data-[state=active]:text-black data-[state=active]:shadow-sm data-[state=inactive]:text-gray-500">Mis Reseñas</TabsTrigger>
          </TabsList>
          
          <TabsContent value="info" className="p-8">
            <div className="space-y-6">
              <div>
                <Label htmlFor="name">Nombre completo</Label>
                <Input 
                  id="name" 
                  name="name" 
                  value={formData.name} 
                  onChange={handleInputChange} 
                  disabled={!isEditing || isLoading}
                  className="mt-1 border-gray-300 focus:border-black focus:ring-black disabled:bg-gray-100"
                />
              </div>
              <div>
                <Label htmlFor="email">Correo electrónico</Label>
                <Input 
                  id="email" 
                  name="email" 
                  value={formData.email} 
                  disabled 
                  className="mt-1 border-gray-300 bg-gray-100 cursor-not-allowed"
                />
              </div>
              <div>
                <Label htmlFor="phone">Número de teléfono</Label>
                <Input 
                  id="phone" 
                  name="phone" 
                  value={formData.phone} 
                  onChange={handleInputChange} 
                  disabled={!isEditing || isLoading}
                  className="mt-1 border-gray-300 focus:border-black focus:ring-black disabled:bg-gray-100"
                />
              </div>
              
              {showPasswordPrompt && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-2 overflow-hidden"
                >
                  <Label htmlFor="currentPassword">Contraseña actual para confirmar</Label>
                  <div className="flex items-center space-x-2">
                    <Input 
                      id="currentPassword" 
                      name="currentPassword" 
                      type="password"
                      value={currentPassword} 
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      className="border-gray-300 focus:border-black focus:ring-black"
                      placeholder="Introduce tu contraseña"
                      disabled={isLoading}
                    />
                    <Button onClick={handlePasswordConfirm} className="bg-black text-white hover:bg-gray-800" disabled={isLoading}>
                      {isLoading ? <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div> : <Lock className="mr-2 h-4 w-4" />} Confirmar
                    </Button>
                  </div>
                </motion.div>
              )}

              <div className="flex justify-between items-center mt-8 border-t border-gray-200 pt-6">
                <Button 
                  onClick={handleEditToggle} 
                  variant={isEditing && !showPasswordPrompt ? "default" : "outline"} 
                  className={isEditing && !showPasswordPrompt ? "bg-black text-white hover:bg-gray-800" : "border-black text-black hover:bg-black hover:text-white"}
                  disabled={isLoading}
                >
                  {isEditing && !showPasswordPrompt ? <Save className="mr-2 h-4 w-4" /> : <Edit3 className="mr-2 h-4 w-4" />}
                  {isEditing && !showPasswordPrompt ? "Guardar Cambios" : "Editar Perfil"}
                </Button>
                {isEditing && showPasswordPrompt && (
                   <Button onClick={() => {setShowPasswordPrompt(false); setIsEditing(false); setCurrentPassword('');}} variant="ghost" className="text-gray-600" disabled={isLoading}>Cancelar</Button>
                )}
                {!isEditing && (
                    <Link to="/forgot-password">
                        <Button variant="link" className="text-sm text-gray-600 hover:text-black p-0 h-auto">¿Olvidaste tu contraseña?</Button>
                    </Link>
                )}
              </div>
              <div className="mt-6 border-t border-gray-200 pt-6">
                <Link to="/favoritos">
                  <Button variant="outline" className="w-full border-gray-300 text-black hover:bg-gray-100">
                    <HeartIcon className="mr-2 h-4 w-4" /> Mis Favoritos
                  </Button>
                </Link>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="purchases" className="p-8">
            <h2 className="text-xl font-semibold text-black mb-4">Mis Compras</h2>
            {userPurchases.length > 0 ? (
              <div className="space-y-4">
                {userPurchases.map(purchase => (
                  <div key={purchase.id} className="p-4 border border-gray-200 bg-white">
                    <h3 className="font-medium text-black">{purchase.name}</h3>
                    <p className="text-gray-600 text-sm mt-1">{purchase.description}</p>
                    <div className="flex justify-between items-center mt-2">
                        <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                            purchase.status === 'En preparación' ? 'bg-yellow-100 text-yellow-800' :
                            purchase.status === 'Enviado' ? 'bg-blue-100 text-blue-800' :
                            purchase.status === 'Finalizada' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                        }`}>
                            {purchase.status}
                        </span>
                        <p className="text-xs text-gray-500">{new Date(purchase.created_at).toLocaleDateString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">Aún no has realizado ninguna compra.</p>
            )}
          </TabsContent>

          <TabsContent value="reviews" className="p-8">
            <h2 className="text-xl font-semibold text-black mb-4">Mis Reseñas</h2>
            {userReviews.length > 0 ? (
              <div className="space-y-4">
                {userReviews.map(review => (
                  <div key={review.id} className="p-4 border border-gray-200 bg-white">
                    <div className="flex justify-between items-start">
                        <div>
                            <h3 className="font-medium text-black">{review.productName || 'Producto no encontrado'}</h3>
                            <div className="flex items-center mt-1 mb-1">
                                {[...Array(5)].map((_, i) => (
                                <Star key={i} className={`h-4 w-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} />
                                ))}
                            </div>
                            <p className="text-xs text-gray-500 mb-2">{new Date(review.created_at).toLocaleDateString()}</p>
                            <p className="text-gray-600 text-sm">{review.comment}</p>
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteReview(review.id)} className="text-red-500 hover:bg-red-100" disabled={isLoading}>
                           {isLoading ? <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-red-500"></div> : <Trash2 className="h-4 w-4" />}
                        </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">Aún no has dejado ninguna reseña.</p>
            )}
          </TabsContent>
        </Tabs>
        
        <div className="p-8 border-t border-gray-200">
            <Button onClick={handleLogout} variant="outline" className="w-full border-red-500 text-red-500 hover:bg-red-500 hover:text-white">
                <LogOut className="mr-2 h-4 w-4" /> Cerrar Sesión
            </Button>
        </div>
      </motion.div>
    </div>
  );
};

export default Profile;