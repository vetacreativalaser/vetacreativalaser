import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import ProductImages from '@/components/product/ProductImages';
import ProductInfo from '@/components/product/ProductInfo';
import ReviewForm from '@/components/product/ReviewForm';
import ReviewsList from '@/components/product/ReviewsList';
import RelatedProducts from '@/components/product/RelatedProducts';

const ProductDetail = () => {
  const { id: productIdParam } = useParams();
  const productId = parseInt(productIdParam);
  const { user } = useAuth();
  const [isFavorite, setIsFavorite] = useState(false);
  const [reviews, setReviews] = useState([]);
  const [newReview, setNewReview] = useState({ rating: 0, comment: '', name: '' });
  const [isLoadingFavorite, setIsLoadingFavorite] = useState(false);
  const [isLoadingReview, setIsLoadingReview] = useState(false);
  const [product, setProduct] = useState(null);
  const [allProducts, setAllProducts] = useState([]);
  const [isLoadingProduct, setIsLoadingProduct] = useState(true);
  
  useEffect(() => {
    const fetchProductAndRelatedData = async () => {
      setIsLoadingProduct(true);

      const { data: productsData, error: productsError } = await supabase
        .from('products')
        .select('*');
      
      if (productsError) {
        console.error("Error fetching all products:", productsError);
        toast({ title: "Error", description: "No se pudieron cargar los productos.", variant: "destructive" });
        setIsLoadingProduct(false);
        return;
      }
      setAllProducts(productsData || []);
      
      const currentProduct = productsData.find(p => p.id === productId);
      setProduct(currentProduct);

      if (user && currentProduct) {
        setIsLoadingFavorite(true);
        const { data, error } = await supabase
          .from('favorites')
          .select('*')
          .eq('user_id', user.id)
          .eq('product_id', currentProduct.id)
          .maybeSingle();
        if (error) console.error("Error checking favorite:", error);
        else setIsFavorite(!!data);
        setIsLoadingFavorite(false);
      }

      if (currentProduct) {
        setIsLoadingReview(true);
        const { data: reviewsData, error: reviewsError } = await supabase
          .from('reviews')
          .select('*, profiles ( name )') 
          .eq('product_id', currentProduct.id)
          .order('created_at', { ascending: false });
        if (reviewsError) console.error("Error fetching reviews:", reviewsError);
        else setReviews((reviewsData || []).map(r => ({...r, name: r.profiles?.name || 'Anónimo' }))); 
        setIsLoadingReview(false);
      }
      setIsLoadingProduct(false);
    };
    
    fetchProductAndRelatedData();
  }, [productId, user]);
  
  useEffect(() => {
    if (user && !newReview.name) {
        setNewReview(prev => ({ ...prev, name: user.name || user.user_metadata?.name || '' }));
    }
  }, [user, newReview.name]);


  const toggleWishlist = async () => {
    if (!user || !product) {
      toast({ title: "Inicia sesión", description: "Debes iniciar sesión para añadir a favoritos.", variant: "destructive" });
      return;
    }
    setIsLoadingFavorite(true);
    if (isFavorite) {
      const { error } = await supabase
        .from('favorites')
        .delete()
        .eq('user_id', user.id)
        .eq('product_id', product.id);
      if (error) toast({ title: "Error", description: error.message, variant: "destructive" });
      else setIsFavorite(false);
    } else {
      const { error } = await supabase
        .from('favorites')
        .insert([{ user_id: user.id, product_id: product.id }]);
      if (error) toast({ title: "Error", description: error.message, variant: "destructive" });
      else setIsFavorite(true);
    }
    toast({
      title: !isFavorite ? "Añadido a Favoritos" : "Eliminado de Favoritos",
      description: product.name,
    });
    setIsLoadingFavorite(false);
  };

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    if (!user || !product) {
      toast({ title: "Inicia sesión", description: "Debes iniciar sesión para dejar una reseña.", variant: "destructive" });
      return;
    }
    if (newReview.rating === 0 || !newReview.comment.trim()) {
      toast({ title: "Campos incompletos", description: "Por favor, completa todos los campos de la reseña.", variant: "destructive" });
      return;
    }
    setIsLoadingReview(true);
    const reviewNameToSave = newReview.name || user.name || user.user_metadata?.name || 'Anónimo';

    const { error } = await supabase
      .from('reviews')
      .insert([{ 
        user_id: user.id, 
        product_id: product.id, 
        rating: newReview.rating, 
        comment: newReview.comment,
        // name: reviewNameToSave, // This field might not be in your reviews table schema, handle accordingly
      }]);

    if (error) {
      toast({ title: "Error al enviar reseña", description: error.message, variant: "destructive" });
    } else {
      const { data: updatedReviews, error: fetchError } = await supabase
        .from('reviews')
        .select('*, profiles(name)')
        .eq('product_id', product.id)
        .order('created_at', { ascending: false });

      if (fetchError) console.error("Error refetching reviews:", fetchError);
      else setReviews((updatedReviews || []).map(r => ({...r, name: r.profiles?.name || reviewNameToSave })));
      
      setNewReview({ rating: 0, comment: '', name: user.name || user.user_metadata?.name || '' });
      toast({ title: "Reseña enviada", description: "¡Gracias por tu opinión!" });
    }
    setIsLoadingReview(false);
  };

  if (isLoadingProduct || !product) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white text-black">
         {isLoadingProduct ? <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div> :
          <div className="text-center">
            <h1 className="text-2xl font-semibold text-black mb-4">Producto no encontrado</h1>
            <Link to="/productos">
              <Button variant="outline" className="border-black text-black hover:bg-black hover:text-white">Volver a Productos</Button>
            </Link>
          </div>
        }
      </div>
    );
  }

  const handleContact = () => {
    const phoneNumber = '642571133';
    const message = encodeURIComponent(`¡Hola! Me interesa el producto "${product.name}". ¿Podrían darme más información?`);
    window.open(`https://wa.me/${phoneNumber}?text=${message}`, '_blank');
  };

  const handleShare = () => {
    toast({
      title: "🚧 Esta función no está implementada aún—¡pero no te preocupes! ¡Puedes solicitarla en tu próximo prompt! 🚀"
    });
  };

  return (
    <div className="min-h-screen py-12 bg-white text-black">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Link to="/productos" className="flex items-center text-gray-500 hover:text-black transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" strokeWidth={1.5}/>
            Volver a Productos
          </Link>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 lg:gap-16">
          <ProductImages product={product} />
          <ProductInfo 
            product={product} 
            isFavorite={isFavorite} 
            isLoadingFavorite={isLoadingFavorite}
            toggleWishlist={toggleWishlist}
            handleShare={handleShare}
            handleContact={handleContact}
          />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-16 pt-12 border-t border-gray-200"
        >
          <h2 className="text-2xl font-semibold text-black mb-8 text-center">
            Opiniones de Clientes
          </h2>
          <ReviewForm 
            user={user} 
            newReview={newReview} 
            setNewReview={setNewReview} 
            handleReviewSubmit={handleReviewSubmit} 
            isLoadingReview={isLoadingReview} 
          />
          <ReviewsList reviews={reviews} isLoadingReview={isLoadingReview} />
        </motion.div>

        <RelatedProducts currentProductId={product.id} allProducts={allProducts} />
      </div>
    </div>
  );
};

export default ProductDetail;