import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Star, Send } from 'lucide-react';

const ReviewForm = ({ user, newReview, setNewReview, handleReviewSubmit, isLoadingReview }) => {
  if (!user) {
    return (
      <p className="text-center text-gray-600 mb-8">
        <Link to="/auth?mode=login" className="text-black underline hover:no-underline">Inicia sesión</Link> para dejar una reseña.
      </p>
    );
  }
  return (
    <form onSubmit={handleReviewSubmit} className="mb-10 p-6 border border-gray-200 bg-gray-50 space-y-4">
      <h3 className="text-lg font-medium text-black">Deja tu reseña</h3>
       <div>
        <Label htmlFor="reviewerName" className="block text-sm font-medium text-gray-700 mb-1">Nombre</Label>
        <Input 
          type="text" 
          id="reviewerName" 
          value={newReview.name} 
          onChange={(e) => setNewReview({...newReview, name: e.target.value})} 
          placeholder="Tu nombre"
          className="border-gray-300 focus:border-black focus:ring-black"
          disabled={!!(user.name || user.user_metadata?.name) || isLoadingReview} 
        />
      </div>
      <div className="flex items-center space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-6 w-6 cursor-pointer ${newReview.rating >= star ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
            onClick={() => !isLoadingReview && setNewReview({...newReview, rating: star})}
          />
        ))}
      </div>
      <Textarea 
        value={newReview.comment} 
        onChange={(e) => setNewReview({...newReview, comment: e.target.value})} 
        placeholder="Escribe tu opinión aquí..." 
        rows={3}
        className="border-gray-300 focus:border-black focus:ring-black"
        disabled={isLoadingReview}
      />
      <Button type="submit" className="bg-black text-white hover:bg-gray-800" disabled={isLoadingReview}>
        {isLoadingReview ? <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div> : <Send className="mr-2 h-4 w-4" />} Enviar Reseña
      </Button>
    </form>
  );
};

export default ReviewForm;