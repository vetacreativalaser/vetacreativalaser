import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { MessageSquare, Heart, Share2 } from 'lucide-react';

const ProductInfo = ({ product, isFavorite, isLoadingFavorite, toggleWishlist, handleShare, handleContact }) => (
  <motion.div
    initial={{ opacity: 0, x: 30 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ duration: 0.5, delay: 0.1 }}
    className="flex flex-col justify-start"
  >
    <h1 className="text-3xl lg:text-4xl font-semibold text-black mb-3">
      {product.name}
    </h1>
    <p className="text-2xl text-gray-700 mb-6">
      {product.price}
    </p>

    <div className="flex items-center space-x-3 mb-6">
      <Button 
        onClick={toggleWishlist} 
        variant="outline" 
        size="icon" 
        className="border-gray-300 hover:border-black h-10 w-10"
        disabled={isLoadingFavorite}
      >
        {isLoadingFavorite ? <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-black"></div> : <Heart className={`h-5 w-5 ${isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-500'}`} strokeWidth={1.5}/>}
      </Button>
      <Button onClick={handleShare} variant="outline" size="icon" className="border-gray-300 hover:border-black h-10 w-10">
        <Share2 className="h-5 w-5 text-gray-500" strokeWidth={1.5}/>
      </Button>
    </div>

    <div className="mb-6">
      <h2 className="text-lg font-semibold text-black mb-2">Descripción</h2>
      <p className="text-gray-600 leading-relaxed text-sm">
        {product.full_description}
      </p>
    </div>

    {product.specifications && product.specifications.length > 0 && (
      <div className="mb-8">
        <h2 className="text-lg font-semibold text-black mb-2">Especificaciones</h2>
        <ul className="list-disc list-inside text-gray-600 space-y-1 text-sm">
          {product.specifications.map((spec, index) => (
            <li key={index}>{spec}</li>
          ))}
        </ul>
      </div>
    )}
    
    <div className="mb-8 p-4 border border-gray-200 bg-gray-50">
      <h2 className="text-lg font-semibold text-black mb-2">Cómo Comprar</h2>
      <p className="text-gray-600 leading-relaxed text-sm mb-2">
        ¡Gracias por tu interés! Al ser una empresa pequeña y artesanal, gestionamos los pedidos de forma personalizada. Para comprar este producto:
      </p>
      <ol className="list-decimal list-inside text-gray-600 space-y-1 text-sm mb-3">
        <li>Contacta con nosotros a través de WhatsApp o email.</li>
        <li>Indícanos el producto que te interesa y cualquier personalización.</li>
        <li>Te confirmaremos los detalles y el precio final (el envío no está incluido, se calcula aparte).</li>
        <li>El pago se realiza de forma segura por Bizum o transferencia.</li>
      </ol>
      <p className="text-gray-600 text-sm font-medium mb-1">¡Soy una persona fiable! Puedes comprobar las reseñas de otros clientes.</p>
      <p className="text-gray-600 text-sm font-semibold">Envío gratuito en pedidos superiores a 60€.</p>
    </div>

    <Button
      onClick={handleContact}
      size="lg"
      className="w-full bg-black text-white hover:bg-gray-800 py-3 uppercase tracking-wider text-sm font-semibold"
    >
      <MessageSquare className="mr-2 h-4 w-4" strokeWidth={2} />
      Contactar para Comprar
    </Button>
    <p className="text-xs text-gray-500 text-center mt-3">
      Contacta con nosotros para personalizar tu producto o resolver cualquier duda.
    </p>
  </motion.div>
);

export default ProductInfo;