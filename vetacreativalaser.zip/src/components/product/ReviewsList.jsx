import React from 'react';
import { Star } from 'lucide-react';

const ReviewsList = ({ reviews, isLoadingReview }) => {
  if (isLoadingReview && reviews.length === 0) {
    return <div className="flex justify-center"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-black"></div></div>;
  }
  if (!isLoadingReview && reviews.length === 0) {
    return <p className="text-center text-gray-500">Aún no hay reseñas para este producto. ¡Sé el primero!</p>;
  }
  return (
    <div className="space-y-6">
      {reviews.map(review => (
        <div key={review.id} className="p-4 border border-gray-200 bg-white">
          <div className="flex items-center mb-1">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className={`h-4 w-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} />
            ))}
             <span className="ml-2 text-sm font-semibold text-black">{review.name || (review.profiles && review.profiles.name) || 'Anónimo'}</span>
          </div>
          <p className="text-xs text-gray-500 mb-2">{new Date(review.created_at).toLocaleDateString()}</p>
          <p className="text-gray-600 text-sm">{review.comment}</p>
        </div>
      ))}
    </div>
  );
};

export default ReviewsList;